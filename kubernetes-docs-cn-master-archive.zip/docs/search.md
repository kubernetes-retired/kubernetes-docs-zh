---
layout: docwithnav
title: Search Results
hideTOC: true
---
<script>

  (function() {
    var cx = '013288817511911618469:elfqqbqldzg';
    var gcse = document.createElement('script');
    gcse.type = 'text/javascript';
    gcse.async = true;
    gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
        '//cse.google.com/cse.js?cx=' + cx;
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(gcse, s);

    document.querySelector('html').classList.add('search');
  })();
</script>
<gcse:searchresults-only linktarget="_parent"></gcse:searchresults-only>
